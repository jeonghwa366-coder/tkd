package com.example.kakaoschedule
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class KakaoNotificationListener:NotificationListenerService(){
 override fun onNotificationPosted(sbn:StatusBarNotification){
  if(sbn.packageName!="com.kakao.talk")return
  val e=sbn.notification.extras
  val text=e.getCharSequence(Notification.EXTRA_TEXT)?.toString()?:return
  ScheduleParser.parse(text)?.let{ScheduleStore.add(this,it)}
 }
}
