package com.example.kakaoschedule
import android.app.Activity
import android.os.Bundle
import android.provider.Settings
import android.content.Intent
import android.graphics.Color
import android.widget.*

class MainActivity:Activity(){
 lateinit var list:LinearLayout
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,28,28,28)}
  root.addView(TextView(this).apply{text="🥋 태권도 일정정리";textSize=27f;setTextColor(Color.BLACK);setPadding(0,0,0,12)})
  root.addView(TextView(this).apply{text="카카오톡 알림을 자동으로 읽어 원생별 결석·휴원·차량 정보를 정리합니다.";textSize=15f;setPadding(0,0,0,16)})
  root.addView(Button(this).apply{text="카카오톡 알림 접근 권한 설정";setOnClickListener{startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))}})
  root.addView(TextView(this).apply{text="최근 자동 정리";textSize=20f;setPadding(0,24,0,10)})
  list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  root.addView(list)
  setContentView(root);refresh()
 }
 fun refresh(){list.removeAllViews();ScheduleStore.items(this).forEach{s->list.addView(TextView(this).apply{text="${s.student} | ${s.period} | ${s.status}\n${s.detail}";textSize=17f;setPadding(8,16,8,16)})}}
 override fun onResume(){super.onResume();if(::list.isInitialized)refresh()}
}
