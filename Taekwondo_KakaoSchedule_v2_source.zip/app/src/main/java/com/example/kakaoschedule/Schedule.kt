package com.example.kakaoschedule

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Schedule(val student:String,val period:String,val status:String,val detail:String,val raw:String)

object ScheduleParser {
 private val statuses=listOf(
  "하루쉼" to "휴원","하루 쉼" to "휴원","쉬어요" to "휴원","쉬겠습니다" to "휴원",
  "결석" to "결석","안 갑니다" to "결석","안가요" to "결석","못 갑니다" to "결석",
  "차량 안 탐" to "차량미탑승","차량안탐" to "차량미탑승","차량 안타요" to "차량미탑승",
  "차량 안 타요" to "차량미탑승","차량 안탑승" to "차량미탑승","등원" to "등원","출석" to "출석"
 )
 fun parse(raw:String):Schedule? {
  val clean=raw.replace("\n"," ").trim()
  if(clean.isEmpty()) return null
  val student=Regex("""^([가-힣]{2,5})(?=\s|하루|결석|오늘|내일|이번|월|화|수|목|금|토|일)""").find(clean)?.groupValues?.get(1)
   ?: Regex("""([가-힣]{2,5})\s*(?:학생)?(?:은|는|이|가)""").find(clean)?.groupValues?.get(1) ?: return null
  var status:String?=null
  for((k,v) in statuses) if(clean.contains(k)){status=v;break}
  if(status==null)return null
  val range=Regex("""(월|화|수|목|금|토|일)\s*[~\-]\s*(월|화|수|목|금|토|일)""").find(clean)?.value
  val single=Regex("""(월|화|수|목|금|토|일)(?:요일)?(?:부터|까지)?""").find(clean)?.value
  val period=when{clean.contains("오늘")->"오늘";clean.contains("내일")->"내일";range!=null->range;single!=null->single;clean.contains("이번주")->"이번 주";else->"날짜 미지정"}
  return Schedule(student,period,status,clean,raw)
 }
}
object ScheduleStore {
 private const val KEY="items"
 fun items(c:Context):List<Schedule>{
  val a=JSONArray(c.getSharedPreferences("s",0).getString(KEY,"[]"))
  return List(a.length()){i->val o=a.getJSONObject(i);Schedule(o.getString("student"),o.getString("period"),o.getString("status"),o.getString("detail"),o.getString("raw"))}
 }
 fun add(c:Context,s:Schedule){
  val all=items(c).toMutableList()
  if(all.none{it.raw==s.raw})all.add(0,s)
  val a=JSONArray()
  all.take(300).forEach{o->a.put(JSONObject().apply{put("student",o.student);put("period",o.period);put("status",o.status);put("detail",o.detail);put("raw",o.raw)})}
  c.getSharedPreferences("s",0).edit().putString(KEY,a.toString()).apply()
 }
}
